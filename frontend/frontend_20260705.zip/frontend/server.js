const express = require("express");
const path = require("path");
const app = express();

// Service worker "kill switch": desregistra o SW antigo e recarrega todos os clientes.
// Isso libera usuários presos com cache antigo sem precisar de rebuild.
// O novo SW se instala imediatamente (skipWaiting), desregistra a si mesmo
// e navega todos os clientes abertos para forçar reload com conteúdo fresco.
app.get('/service-worker.js', (req, res) => {
  res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  res.set('Content-Type', 'application/javascript');
  res.send(`
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', () => {
  self.registration.unregister()
    .then(() => self.clients.matchAll({ includeUncontrolled: true }))
    .then(clients => clients.forEach(client => client.navigate(client.url)));
});
  `);
});

app.get('/precache-manifest.*.js', (req, res) => {
  res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  const filename = path.basename(req.path);
  res.sendFile(path.join(__dirname, 'build', filename));
});

// Arquivos /static/* têm hash no nome (ex: main.abc123.js), podem ser
// cacheados por 1 ano com segurança — quando mudam, o nome muda junto
app.use('/static', express.static(path.join(__dirname, 'build', 'static'), {
  maxAge: '1y',
  immutable: true,
}));

// Demais arquivos estáticos (imagens, manifest.json, etc.)
app.use(express.static(path.join(__dirname, 'build'), { index: false }));

const fs = require("fs");

// Lê o logo em base64 para embutir na página de manutenção (não depende do build)
function getLogoDataUrl() {
  const logoPath = path.join(__dirname, 'src', 'assets', 'logo1.png');
  try {
    const data = fs.readFileSync(logoPath);
    return 'data:image/png;base64,' + data.toString('base64');
  } catch (e) {
    return '';
  }
}

function buildMaintenancePage() {
  const logoSrc = getLogoDataUrl();
  const logoHtml = logoSrc
    ? `<img src="${logoSrc}" alt="ATalk" class="logo-img" />`
    : `<div class="logo-text">ATalk</div>`;

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ATalk — Atualizando...</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      min-height: 100vh;
      display: flex;
      background: #f8f9fa;
      overflow: hidden;
    }

    /* ── ESQUERDA ─────────────────────────────── */
    .left {
      flex: 1;
      background: #ffffff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 48px 32px;
      min-height: 100vh;
    }

    .inner {
      width: 100%;
      max-width: 420px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .logo-img {
      width: 180px;
      height: auto;
      margin-bottom: 36px;
      filter: drop-shadow(0 2px 8px rgba(0,0,0,0.10));
    }

    .logo-text {
      font-size: 2.4rem;
      font-weight: 800;
      color: #667eea;
      letter-spacing: -1px;
      margin-bottom: 36px;
    }

    /* badge "Nova versão" */
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      background: linear-gradient(135deg, #f7fafc, #edf2f7);
      border: 1px solid #e2e8f0;
      border-radius: 20px;
      padding: 6px 18px;
      font-size: 0.78rem;
      color: #667eea;
      font-weight: 500;
      margin-bottom: 22px;
    }
    .badge-dot {
      width: 7px; height: 7px;
      border-radius: 50%;
      background: #667eea;
      animation: pulse-dot 1.2s ease-in-out infinite;
    }
    @keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:0.3} }

    /* card branco */
    .card {
      background: #ffffff;
      border-radius: 20px;
      padding: 40px 36px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.10);
      width: 100%;
      text-align: center;
    }

    /* spinner */
    .spinner {
      width: 60px; height: 60px;
      border: 4px solid #edf2f7;
      border-top-color: #667eea;
      border-radius: 50%;
      animation: spin 0.85s linear infinite;
      margin: 0 auto 28px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    .card h1 {
      font-size: 1.35rem;
      font-weight: 700;
      color: #2d3748;
      margin-bottom: 12px;
    }

    .card p {
      font-size: 0.93rem;
      color: #718096;
      line-height: 1.75;
      margin-bottom: 28px;
    }

    /* barra de progresso indeterminada */
    .progress-bar {
      height: 4px;
      background: #edf2f7;
      border-radius: 2px;
      overflow: hidden;
      margin-bottom: 16px;
    }
    .progress-fill {
      height: 100%;
      width: 40%;
      background: linear-gradient(90deg, #667eea, #764ba2);
      border-radius: 2px;
      animation: slide 1.6s ease-in-out infinite;
    }
    @keyframes slide {
      0%   { margin-left: -40%; }
      100% { margin-left: 100%; }
    }

    .checking {
      font-size: 0.8rem;
      color: #a0aec0;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 3px;
    }
    .dot {
      display: inline-block;
      width: 4px; height: 4px;
      border-radius: 50%;
      background: #667eea;
      animation: blink 1.4s infinite;
    }
    .dot:nth-child(2) { animation-delay: 0.2s; }
    .dot:nth-child(3) { animation-delay: 0.4s; }
    @keyframes blink { 0%,80%,100%{opacity:0.15} 40%{opacity:1} }

    .footer {
      margin-top: 28px;
      font-size: 0.78rem;
      color: #cbd5e0;
      text-align: center;
    }
    .footer strong { color: #a0aec0; }

    /* ── DIREITA ──────────────────────────────── */
    .right {
      flex: 1;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: none;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
    }

    /* círculos decorativos */
    .circle {
      position: absolute;
      border-radius: 50%;
      background: rgba(255,255,255,0.06);
    }
    .c1 { width: 520px; height: 520px; top: -120px; right: -120px; }
    .c2 { width: 320px; height: 320px; bottom: -60px; left: -80px; }
    .c3 { width: 180px; height: 180px; top: 38%; left: 18%; background: rgba(255,255,255,0.04); }
    .c4 { width: 70px;  height: 70px;  top: 14%; left: 32%; background: rgba(255,255,255,0.12); }
    .c5 { width: 110px; height: 110px; bottom: 18%; right: 14%; background: rgba(255,255,255,0.08); }

    .right-content {
      position: relative;
      z-index: 1;
      color: #fff;
      text-align: center;
      padding: 40px;
      max-width: 400px;
    }

    .icon-wrap {
      width: 96px; height: 96px;
      border-radius: 26px;
      background: rgba(255,255,255,0.15);
      border: 1px solid rgba(255,255,255,0.25);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 28px;
      animation: float 2.4s ease-in-out infinite;
    }
    @keyframes float {
      0%,100% { transform: translateY(0); box-shadow: 0 8px 24px rgba(0,0,0,0.15); }
      50%      { transform: translateY(-8px); box-shadow: 0 16px 32px rgba(0,0,0,0.20); }
    }

    .right-content h2 {
      font-size: 1.9rem;
      font-weight: 700;
      margin-bottom: 14px;
      text-shadow: 0 2px 8px rgba(0,0,0,0.15);
    }

    .right-content .sub {
      font-size: 0.97rem;
      opacity: 0.85;
      line-height: 1.7;
      margin-bottom: 32px;
    }

    .steps {
      display: flex;
      flex-direction: column;
      gap: 12px;
      text-align: left;
    }
    .step {
      display: flex;
      align-items: center;
      gap: 14px;
      background: rgba(255,255,255,0.10);
      border-radius: 12px;
      padding: 12px 16px;
      font-size: 0.9rem;
    }
    .step-dot {
      width: 9px; height: 9px;
      border-radius: 50%;
      background: rgba(255,255,255,0.45);
      flex-shrink: 0;
    }
    .step.active .step-dot {
      background: #fff;
      box-shadow: 0 0 0 3px rgba(255,255,255,0.30);
      animation: pulse-dot 1s ease-in-out infinite;
    }

    /* responsivo */
    @media (min-width: 768px) {
      .right { display: flex; }
    }
    @media (max-width: 767px) {
      .left { padding: 40px 24px; }
    }
  </style>
</head>
<body>

  <!-- ESQUERDA -->
  <div class="left">
    <div class="inner">
      ${logoHtml}

      <div class="badge">
        <span class="badge-dot"></span>
        Nova versão disponível
      </div>

      <div class="card">
        <div class="spinner"></div>
        <h1>Atualizando o sistema</h1>
        <p>
          Uma nova versão está sendo instalada.<br>
          A página recarregará automaticamente<br>assim que estiver pronta.
        </p>
        <div class="progress-bar"><div class="progress-fill"></div></div>
        <div class="checking">
          Verificando
          <span class="dot"></span>
          <span class="dot"></span>
          <span class="dot"></span>
        </div>
      </div>

      <div class="footer">Desenvolvido por <strong>IRYD</strong></div>
    </div>
  </div>

  <!-- DIREITA -->
  <div class="right">
    <div class="circle c1"></div>
    <div class="circle c2"></div>
    <div class="circle c3"></div>
    <div class="circle c4"></div>
    <div class="circle c5"></div>

    <div class="right-content">
      <div class="icon-wrap">
        <svg width="46" height="46" viewBox="0 0 24 24" fill="white">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/>
        </svg>
      </div>
      <h2>Melhorias a caminho!</h2>
      <p class="sub">
        Estamos instalando uma nova versão<br>com novidades e melhorias para você.
      </p>
      <div class="steps">
        <div class="step active">
          <div class="step-dot"></div>
          <span>Instalando nova versão</span>
        </div>
        <div class="step">
          <div class="step-dot"></div>
          <span>Otimizando recursos</span>
        </div>
        <div class="step">
          <div class="step-dot"></div>
          <span>Pronto para usar</span>
        </div>
      </div>
    </div>
  </div>

  <script>
    setInterval(async () => {
      try {
        const res = await fetch(location.href, { cache: 'no-store' });
        if (res.headers.get('x-app-ready') === '1') location.reload();
      } catch(e) {}
    }, 4000);
  </script>
</body>
</html>`;
}

const MAINTENANCE_PAGE = buildMaintenancePage();

// index.html: nunca cachear — é ele que referencia os novos hashes de JS/CSS
app.get('/*', function (req, res) {
  res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');

  const indexPath = path.join(__dirname, 'build', 'index.html');
  if (!fs.existsSync(indexPath)) {
    res.set('Content-Type', 'text/html; charset=utf-8');
    return res.send(MAINTENANCE_PAGE);
  }

  res.set('x-app-ready', '1');
  res.sendFile(indexPath);
});

app.listen(3000);
