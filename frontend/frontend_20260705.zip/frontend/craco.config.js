module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // Handle .mjs files
      webpackConfig.module.rules.push({
        test: /\.mjs$/,
        include: /node_modules/,
        type: "javascript/auto",
      });

      // Transformar pacotes que usam class fields (fast-png e iobuffer, deps do jspdf)
      webpackConfig.module.rules.push({
        test: /\.(js|mjs|cjs)$/,
        include: [/node_modules\/(fast-png|iobuffer)/],
        use: {
          loader: require.resolve("babel-loader"),
          options: {
            plugins: [
              require.resolve("@babel/plugin-proposal-class-properties"),
            ],
            cacheDirectory: true,
            cacheCompression: false,
            compact: false,
          },
        },
      });

      // Skip performance hints (evita processamento extra)
      webpackConfig.performance = false;

      // Otimizar terser para máquina com pouca RAM e 1 core
      if (webpackConfig.optimization && webpackConfig.optimization.minimizer) {
        webpackConfig.optimization.minimizer.forEach((plugin) => {
          if (
            plugin.constructor.name === "TerserPlugin" ||
            (plugin.options && plugin.options.terserOptions)
          ) {
            plugin.options.parallel = false; // 1 core: parallel cria overhead de workers
            plugin.options.cache = true;     // reutiliza cache entre builds
            plugin.options.terserOptions = {
              parse: { ecma: 8 },
              compress: {
                ecma: 5,
                passes: 1,       // 1 passagem é suficiente
                inline: 1,
                drop_console: false,
              },
              mangle: { safari10: true },
              output: {
                ecma: 5,
                comments: false,
                ascii_only: true,
              },
            };
          }
        });
      }

      // Desativar scope hoisting reduz pico de memória no link dos módulos
      webpackConfig.optimization.concatenateModules = false;

      // Limitar splitChunks para gerar menos chunks e usar menos memória
      webpackConfig.optimization.splitChunks = {
        ...webpackConfig.optimization.splitChunks,
        maxSize: 1024 * 1024, // 1MB max por chunk
      };

      return webpackConfig;
    },
  },
};
