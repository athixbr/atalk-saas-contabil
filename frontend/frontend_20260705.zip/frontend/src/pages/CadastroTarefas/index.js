import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Box,
  Card,
  CardActionArea,
  CardContent,
  Grid,
  Typography,
} from "@material-ui/core";
import { useHistory } from "react-router-dom";
import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import Title from "../../components/Title";
import { TaskSquare, Calendar, Setting3, HierarchySquare3, MoneySend } from "iconsax-react";

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(3),
    overflowY: "auto",
  },
  grid: {
    marginTop: theme.spacing(2),
  },
  card: {
    borderRadius: 16,
    border: "1px solid rgba(0,0,0,0.08)",
    boxShadow: "0 2px 12px rgba(0,0,0,0.06)",
    transition: "all 0.2s ease",
    "&:hover": {
      boxShadow: "0 6px 24px rgba(6, 81, 131, 0.15)",
      transform: "translateY(-2px)",
    },
  },
  cardContent: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    padding: theme.spacing(3),
  },
  iconWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 52,
    height: 52,
    borderRadius: 14,
    backgroundColor: "#065183",
    marginBottom: theme.spacing(2),
    color: "#fff",
  },
  cardTitle: {
    fontFamily: "Inter, sans-serif",
    fontWeight: 600,
    fontSize: "1rem",
    color: "#1a1a2e",
    marginBottom: theme.spacing(0.5),
  },
  cardDescription: {
    fontFamily: "Inter, sans-serif",
    fontSize: "0.82rem",
    color: "#666",
    lineHeight: 1.5,
  },
  subLink: {
    marginTop: theme.spacing(2),
    display: "flex",
    gap: theme.spacing(1),
    flexWrap: "wrap",
  },
  chip: {
    display: "inline-flex",
    alignItems: "center",
    gap: 4,
    padding: "4px 10px",
    borderRadius: 8,
    backgroundColor: "rgba(6, 81, 131, 0.08)",
    color: "#065183",
    fontSize: "0.75rem",
    fontWeight: 500,
    cursor: "pointer",
    transition: "background 0.15s",
    "&:hover": {
      backgroundColor: "rgba(6, 81, 131, 0.18)",
    },
  },
}));

const ITEMS = [
  {
    title: "Cadastro de Tarefas",
    description: "Gerencie os tipos de tarefas disponíveis no sistema.",
    icon: <TaskSquare size={24} color="#fff" />,
    path: "/tarefas-config",
  },
  {
    title: "Recorrências",
    description: "Configure tarefas recorrentes e seus modelos de repetição.",
    icon: <Calendar size={24} color="#fff" />,
    path: "/recorrencia",
  },
  {
    title: "Controles",
    description: "Gerencie controles e vínculos entre clientes e serviços.",
    icon: <Setting3 size={24} color="#fff" />,
    subItems: [
      { label: "Cadastro de Controles", path: "/controles-config", icon: <Setting3 size={14} /> },
      { label: "Central de Vínculos", path: "/central-vinculos", icon: <HierarchySquare3 size={14} /> },
    ],
  },
  {
    title: "Parcelamentos",
    description: "Gerencie parcelamentos de tarefas e serviços recorrentes.",
    icon: <MoneySend size={24} color="#fff" />,
    path: "/parcelamentos",
  },
];

const CadastroTarefas = () => {
  const classes = useStyles();
  const history = useHistory();

  return (
    <MainContainer>
      <MainHeader>
        <Title>Cadastro</Title>
      </MainHeader>

      <Box className={classes.mainPaper}>
        <Typography variant="body2" style={{ color: "#666", marginBottom: 8, fontFamily: "Inter, sans-serif" }}>
          Selecione uma categoria para gerenciar os cadastros de gestão de tarefas.
        </Typography>

        <Grid container spacing={3} className={classes.grid}>
          {ITEMS.map((item) => (
            <Grid item xs={12} sm={6} md={4} key={item.title}>
              {item.subItems ? (
                <Card className={classes.card} elevation={0}>
                  <CardContent className={classes.cardContent}>
                    <Box className={classes.iconWrapper}>{item.icon}</Box>
                    <Typography className={classes.cardTitle}>{item.title}</Typography>
                    <Typography className={classes.cardDescription}>{item.description}</Typography>
                    <Box className={classes.subLink}>
                      {item.subItems.map((sub) => (
                        <Box
                          key={sub.path}
                          className={classes.chip}
                          onClick={() => history.push(sub.path)}
                        >
                          {sub.icon}
                          {sub.label}
                        </Box>
                      ))}
                    </Box>
                  </CardContent>
                </Card>
              ) : (
                <Card className={classes.card} elevation={0}>
                  <CardActionArea onClick={() => history.push(item.path)}>
                    <CardContent className={classes.cardContent}>
                      <Box className={classes.iconWrapper}>{item.icon}</Box>
                      <Typography className={classes.cardTitle}>{item.title}</Typography>
                      <Typography className={classes.cardDescription}>{item.description}</Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              )}
            </Grid>
          ))}
        </Grid>
      </Box>
    </MainContainer>
  );
};

export default CadastroTarefas;
